import { useEffect, useState, type ReactNode } from 'react'
import { useTranslation } from 'react-i18next'
import { Link } from 'react-router-dom'
import { DriverCard, FleetRow, RatingBadge } from '../components/cards'
import { PremiumBadge, RewardsStrip, TickBadge, TickDot, tickOf } from '../components/rewards'
import { ProfileNudges } from '../components/nudges'
import { Avatar } from '../components/photo'
import { placeText } from '../components/places'
import { AppShell } from '../components/shell'
import { ButtonLink, Card, ConfirmDialog, Icon, SectionTitle } from '../components/ui'
import { HistoryNudge, useHistoryRequests, useMyHistory } from '../components/history'
import { useAuth } from '../lib/auth'
import { brand } from '../lib/brand'
import { driverCompletion, ownerCompletion } from '../lib/completion'
import { useIsDesktop } from '../lib/layout'
import { track, trackScreen } from '../lib/track'
import { DigitalCardLauncher } from '../components/growth'

/** "Profile": who I am, how complete my profile is, how others see me, and account links. */
export default function Profile() {
  const { t, i18n } = useTranslation()
  const { profile, driver, fleet, logout } = useAuth()
  const desktop = useIsDesktop()
  const [confirm, setConfirm] = useState(false)
  const [card, setCard] = useState(false)
  useEffect(() => { trackScreen('profile_tab') }, [])
  if (!profile) return null
  const isDriver = profile.role === 'driver'
  const done = isDriver ? driverCompletion(profile, driver) : ownerCompletion(profile, fleet)
  const histSum = useMyHistory(isDriver)
  const reqs = useHistoryRequests(!isDriver)
  const phone = (profile.phone || '').replace(/^91/, '')
  const place = profile.district && profile.state ? placeText({ district: profile.district, state: profile.state }, i18n.language) : ''
  const vehicles = fleet.reduce((s, g) => s + g.vehicle_count, 0)
  const tick = tickOf(profile.tick, profile.verified)
  const premium = !!profile.premium_until && new Date(profile.premium_until) > new Date()

  const identity = (
    <Card pad={false} className="overflow-hidden">
      <div className="surface-hero h-20" aria-hidden />
      <div className="-mt-10 flex flex-col items-center px-card pb-card text-center lg:items-start lg:text-left">
        <span className="relative rounded-full ring-4 ring-surface">
          <Avatar url={profile.photo_url} name={profile.name} size={80} />
          <TickDot tick={tick} size={24} className="absolute bottom-0.5 right-0.5" />
        </span>
        <p className="mt-2 max-w-full truncate font-display text-xl font-semibold tracking-[-0.01em]">{profile.name}</p>
        <p className="text-sm text-text-2">{isDriver ? t('role.driver') : profile.business_name || t('role.owner')}</p>
        <div className="mt-2.5 flex flex-wrap items-center justify-center gap-2 lg:justify-start">
          <TickBadge tick={tick} />
          <PremiumBadge on={premium} />
          <RatingBadge />
        </div>
        <dl className="mt-4 w-full divide-y divide-border rounded-md bg-surface-2 text-sm ring-1 ring-inset ring-border">
          <div className="flex items-center gap-2.5 px-3 py-2"><dt className="sr-only">{t('profile.phone')}</dt><span className="text-text-3 [&>svg]:size-icon-sm">{Icon.phone}</span><dd className="font-medium">+91 {phone.slice(0, 5)} {phone.slice(5)}</dd></div>
          {place && <div className="flex items-center gap-2.5 px-3 py-2"><dt className="sr-only">{t('profile.place')}</dt><span className="text-text-3 [&>svg]:size-icon-sm">{Icon.pin}</span><dd className="truncate font-medium">{place}</dd></div>}
        </dl>
        {!profile.verified && (
          <Link to="/verify" onClick={() => track('verify_open', { from: 'profile' })}
            className="press mt-3 flex w-full items-center gap-3 rounded-md bg-success-soft px-3 py-2 text-left font-semibold text-success ring-1 ring-inset ring-success/20 hover:brightness-[0.98]">
            <span className="icon-tile size-8 bg-success text-on-success [&>svg]:size-icon-sm">{Icon.shield}</span><span className="flex-1">{t('verify.getBadge')}</span>{Icon.chevron}
          </Link>
        )}
        <ButtonLink to="/setup?edit" variant="outline" block className="mt-3">{t('profile.edit')}</ButtonLink>
      </div>
    </Card>
  )

  const links = (
    <nav aria-label={t('profile.more')} className="overflow-hidden rounded-lg border border-border bg-surface shadow-sm">
      <Row to="/rewards" icon={Icon.crown} label={t('rw.title')} />
      {!isDriver && <Row to="/setup?step=fleet" icon={Icon.truck} label={t('profile.vehicles', { n: vehicles })} />}
      {isDriver && <Row to="/history" icon={Icon.history} label={t('hist.title')} />}
      {!isDriver && <Row to="/history-requests" icon={Icon.history} label={reqs ? `${t('hist.reqTitle')} (${reqs})` : t('hist.reqTitle')} />}
      {isDriver && <Row onClick={() => { setCard(true); track('card_open', { from: 'profile' }) }} icon={Icon.idcard} label={t('card.mine')} />}
      <Row to="/invite" icon={Icon.gift} label={t('growth.invite')} />
      <Row to="/blocked" icon={Icon.ban} label={t('trust.blockedList')} />
      <Row to="/settings" icon={Icon.settings} label={t('settings.title')} />
      <Row href={`tel:${brand.supportPhone}`} icon={Icon.help} label={t('profile.help')} />
      <Row to="/legal" icon={Icon.doc} label={t('login.terms')} />
      <Row onClick={() => setConfirm(true)} icon={Icon.logout} label={t('settings.logout')} danger last />
    </nav>
  )

  const preview = isDriver && driver && driver.vehicles.length > 0 ? (
    <section>
      <SectionTitle className="mb-3" title={t('profile.ownersSee')} sub={t('profile.ownersSeeSub')}
        right={<Link to="/setup?edit" className="shrink-0 font-semibold text-primary hover:underline">{t('home.edit')}</Link>} />
      <div className="max-w-xl"><DriverCard self data={{ history: histSum && histSum.count ? histSum : undefined, name: profile.name || '', photo_url: profile.photo_url, place: place.replace(/ · \d+$/, ''), verified: profile.verified, tick, premium, d: driver }} /></div>
    </section>
  ) : !isDriver && fleet.length > 0 ? (
    <section>
      <SectionTitle className="mb-3" title={t('home.yourVehicles')}
        right={<Link to="/setup?step=fleet" className="shrink-0 font-semibold text-primary hover:underline">{t('home.edit')}</Link>} />
      <div className="grid gap-2.5 xl:grid-cols-2">{fleet.map((g) => <FleetRow key={g.id} g={g} />)}</div>
    </section>
  ) : null

  return (
    <AppShell title={t('tabs.profile')} width="default">
      {desktop ? (
        <div className="grid grid-cols-[320px_minmax(0,1fr)] items-start gap-8">
          <div className="flex flex-col gap-4">{identity}{links}</div>
          <div className="flex min-w-0 flex-col gap-6">
            <RewardsStrip points={profile.points || 0} tick={tick} premium={premium} />
            <ProfileNudges role={isDriver ? 'driver' : 'owner'} done={done} />
            {isDriver && <HistoryNudge s={histSum} />}
            {preview}
          </div>
        </div>
      ) : (
        <div className="flex flex-col gap-4">
          {identity}
          <RewardsStrip points={profile.points || 0} tick={tick} premium={premium} />
          <ProfileNudges role={isDriver ? 'driver' : 'owner'} done={done} />
          {isDriver && <HistoryNudge s={histSum} />}
          {preview}
          {links}
        </div>
      )}
      {card && <DigitalCardLauncher onClose={() => setCard(false)} />}
      <ConfirmDialog open={confirm} title={t('settings.logoutQ')} confirmLabel={t('settings.logout')}
        onCancel={() => setConfirm(false)} onConfirm={() => { setConfirm(false); void logout(false) }} />
    </AppShell>
  )
}

function Row({ to, href, onClick, icon, label, last, danger }: { to?: string; href?: string; onClick?: () => void; icon: ReactNode; label: string; last?: boolean; danger?: boolean }) {
  const cls = `group flex min-h-ctl-lg w-full items-center gap-3 px-3 py-1.5 text-left font-medium transition-colors hover:bg-surface-2 ${last ? '' : 'border-b border-border'} ${danger ? 'text-error' : ''}`
  const inner = (
    <>
      <span className={`icon-tile size-9 [&>svg]:size-icon-md ${danger ? 'bg-error-soft text-error' : 'bg-primary-soft text-primary'}`}>{icon}</span>
      <span className="flex-1">{label}</span>
      {!danger && <span className="text-text-3 transition-transform group-hover:translate-x-0.5">{Icon.chevron}</span>}
    </>
  )
  if (to) return <Link to={to} className={cls}>{inner}</Link>
  if (href) return <a href={href} className={cls}>{inner}</a>
  return <button type="button" onClick={onClick} className={cls}>{inner}</button>
}
