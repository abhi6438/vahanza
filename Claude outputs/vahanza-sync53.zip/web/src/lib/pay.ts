/**
 * Paid Premium through Razorpay Checkout (UPI / card / netbanking). Loaded only when someone taps "pay".
 * The server creates the order and checks the signature; nothing here is trusted on its own.
 */
import { brand } from './brand'
import { rewards, type Plan } from './api'

type RazorpayResponse = { razorpay_order_id: string; razorpay_payment_id: string; razorpay_signature: string }
type RazorpayCtor = new (o: Record<string, unknown>) => { open: () => void; on: (ev: string, cb: (e: unknown) => void) => void }

let loading: Promise<RazorpayCtor> | null = null
function loadCheckout(): Promise<RazorpayCtor> {
  const w = window as unknown as { Razorpay?: RazorpayCtor }
  if (w.Razorpay) return Promise.resolve(w.Razorpay)
  loading ??= new Promise((resolve, reject) => {
    const s = document.createElement('script')
    s.src = 'https://checkout.razorpay.com/v1/checkout.js'
    s.async = true
    s.onload = () => (w.Razorpay ? resolve(w.Razorpay) : reject(new Error('no Razorpay')))
    s.onerror = () => { loading = null; reject(new Error('checkout failed to load')) }
    document.head.appendChild(s)
  })
  return loading
}

/** Opens the checkout. Resolves true when paid + confirmed by the server, false when the person closed it. */
export async function payForPremium(plan: Plan['id'], description: string): Promise<boolean> {
  const [Rzp, order] = await Promise.all([loadCheckout(), rewards.order(plan)])
  return new Promise((resolve, reject) => {
    const rzp = new Rzp({
      key: order.key_id,
      order_id: order.order_id,
      amount: order.amount,
      currency: order.currency,
      name: brand.name,
      description,
      prefill: { contact: order.contact || undefined, name: order.name || undefined },
      theme: { color: getComputedStyle(document.documentElement).getPropertyValue('--c-brand').trim() || undefined },
      modal: { ondismiss: () => resolve(false) },
      handler: (r: RazorpayResponse) => {
        rewards.paid({ order_id: r.razorpay_order_id, payment_id: r.razorpay_payment_id, signature: r.razorpay_signature })
          .then(() => resolve(true)).catch(reject)
      },
    })
    rzp.on('payment.failed', () => resolve(false))
    rzp.open()
  })
}
