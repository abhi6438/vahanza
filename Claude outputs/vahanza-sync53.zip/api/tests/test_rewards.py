"""Rewards: points, ticks, Premium (points + paid), Premium gates."""
import hashlib
import hmac
import json
from datetime import datetime, timedelta, timezone

from conftest import make_token
from vz import rewards as R
from vz.config import get_settings

H = {"Authorization": f"Bearer {make_token()}"}
ME = {"id": "11111111-1111-1111-1111-111111111111", "tenant_id": "vahanza", "role": "driver", "blocked": False, "name": "Sunil Verma",
      "phone": "919811177003", "points": 600, "tick": "blue", "premium_until": None, "is_test": False}
LATER = datetime.now(timezone.utc) + timedelta(days=10)


def test_award_once_and_cap(db):
    db.respond("insert into public.reward_ledger", {"points": 100})
    assert R.award(db, "vahanza", "u1", "history_confirmed", "e1") == 100
    assert any("set points = points + %s" in c[0] for c in db.calls)
    # already given (insert returns nothing) → 0, no balance change
    db.calls.clear()
    assert R.award(db, "vahanza", "u1", "history_confirmed", "e1") == 0
    assert not any("points = points +" in c[0] for c in db.calls)
    # capped kind
    db.respond("count(*) as n from public.reward_ledger", {"n": 5})
    assert R.award(db, "vahanza", "u1", "history_add", "e9") == 0
    # wrong role
    assert R.award(db, "vahanza", "u1", "post_live", "p1", role="driver") == 0


def test_once_kinds_use_empty_ref(db):
    db.respond("insert into public.reward_ledger", {"points": 50})
    R.award(db, "vahanza", "u1", "profile_done", "anything")
    ins = next(c for c in db.calls if "insert into public.reward_ledger" in c[0])[1]
    assert ins[4] == ""


def test_premium_with_points(client, db):
    db.respond("from public.profiles where id", ME)
    db.respond("set points = points - %s", {"points": 100})
    db.respond("set premium_until = greatest", {"premium_until": LATER})
    r = client.post("/api/v1/me/premium/points", headers=H, json={"plan": "m1"})
    assert r.status_code == 200 and r.json()["premium"] is True
    spent = next(c for c in db.calls if "insert into public.reward_ledger" in c[0])[1]
    assert spent[2] == "premium" and spent[3] == -500


def test_premium_not_enough_points(client, db):
    db.respond("from public.profiles where id", dict(ME, points=20))
    r = client.post("/api/v1/me/premium/points", headers=H, json={"plan": "m3"})
    assert r.status_code == 409 and r.json()["detail"]["need"] == 1300
    assert not any("premium_until" in c[0] and "update" in c[0] for c in db.calls)


def test_paid_off_without_keys(client, db):
    db.respond("from public.profiles where id", ME)
    assert client.post("/api/v1/me/premium/order", headers=H, json={"plan": "m1"}).status_code == 503


def test_paid_signature(client, db, monkeypatch):
    s = get_settings()
    monkeypatch.setattr(s, "razorpay_key_id", "rzp_test_x")
    monkeypatch.setattr(s, "razorpay_key_secret", "sec123")
    sig = hmac.new(b"sec123", b"order_1|pay_1", hashlib.sha256).hexdigest()
    db.respond("from public.profiles where id", ME)
    assert client.post("/api/v1/me/premium/paid", headers=H, json={"order_id": "order_1", "payment_id": "pay_1", "signature": "bad"}).status_code == 400
    db.respond("from public.profiles where id", ME)
    db.respond("from public.payment_orders where order_id", {"status": "created"})
    db.respond("update public.payment_orders set status = 'paid'", {"tenant_id": "vahanza", "user_id": ME["id"], "plan": "m1", "amount_paise": 4900})
    db.respond("select role from public.profiles", {"role": "driver"})
    db.respond("set premium_until = greatest", {"premium_until": LATER})
    r = client.post("/api/v1/me/premium/paid", headers=H, json={"order_id": "order_1", "payment_id": "pay_1", "signature": sig})
    assert r.status_code == 200 and r.json()["premium"] is True
    grant = next(c for c in db.calls if "insert into public.premium_passes" in c[0])[1]
    assert grant[3] == "paid" and grant[4] == 30 and grant[6] == 4900


def test_webhook_checks_signature(client, db, monkeypatch):
    monkeypatch.setattr(get_settings(), "razorpay_webhook_secret", "wh1")
    body = json.dumps({"event": "payment.captured", "payload": {"payment": {"entity": {"id": "pay_9", "order_id": "order_9"}}}}).encode()
    assert client.post("/api/v1/hooks/razorpay", content=body, headers={"X-Razorpay-Signature": "nope"}).status_code == 401
    sig = hmac.new(b"wh1", body, hashlib.sha256).hexdigest()
    r = client.post("/api/v1/hooks/razorpay", content=body, headers={"X-Razorpay-Signature": sig, "Content-Type": "application/json"})
    assert r.status_code == 200
    assert any("update public.payment_orders set status = 'paid'" in c[0] for c in db.calls)


def test_full_history_is_premium_for_owners(client, db):
    owner = dict(ME, role="owner")
    rows = [{"id": f"e{i}", "owner_id": None, "owner_name": "Shyam", "firm_name": "Shyam Roadways", "owner_district": "Satna",
             "owner_state": "MP", "vehicle": "bus", "wheels": None, "start_month": datetime(2021, 5, 1).date(), "end_month": None,
             "work_type": None, "area": None, "note": None, "source": "driver", "status": "confirmed", "owner_answer": "yes",
             "owner_stars": 5, "owner_tags": ["safe"], "rehire": True, "invite_count": 0, "invited_at": None, "answered_at": None,
             "hidden": False, "created_at": None} for i in range(3)]
    db.respond("from public.profiles where id", owner)
    db.respond("select premium_until from public.profiles", {"premium_until": None})
    db.respond("from public.work_history h join public.profiles d", rows)
    r = client.get("/api/v1/drivers/22222222-2222-2222-2222-222222222222/history", headers=H).json()
    assert r["locked"] is True and r["more"] == 2 and len(r["items"]) == 1
    assert r["items"][0]["owner_stars"] is None and r["summary"]["confirmed"] == 3
    db.respond("from public.profiles where id", owner)
    db.respond("select premium_until from public.profiles", {"premium_until": LATER})
    db.respond("from public.work_history h join public.profiles d", rows)
    r = client.get("/api/v1/drivers/22222222-2222-2222-2222-222222222222/history", headers=H).json()
    assert r["locked"] is False and len(r["items"]) == 3 and r["items"][0]["owner_stars"] == 5


def test_tick_filter_needs_premium(client, db):
    db.respond("from public.profiles where id", {"id": ME["id"], "tenant_id": "vahanza", "role": "owner", "is_test": False,
                                                  "blocked": False, "district": "Rewa", "location": None})
    db.respond("select premium_until from public.profiles", {"premium_until": None})
    assert client.get("/api/v1/drivers?tick=gold", headers=H).status_code == 402


def test_profile_viewers_names_only_for_premium(client, db):
    db.respond("from public.profiles where id", ME)
    db.respond("from public.profile_views where driver_id", {"week": 3, "month": 7})
    r = client.get("/api/v1/me/profile-viewers", headers=H).json()
    assert r == {"week": 3, "month": 7, "premium": False, "items": []}


def test_admin_black_tick_and_premium(client, db):
    db.respond("from public.profiles where id", {"id": ME["id"], "tenant_id": "vahanza", "role": "admin", "blocked": False})
    db.respond("role in ('driver', 'owner')", {"id": "x", "role": "driver"})
    db.respond("set premium_until = greatest", {"premium_until": LATER})
    db.respond("select tick, tick_black, points, premium_until", {"tick": "black", "tick_black": True, "points": 10, "premium_until": LATER})
    r = client.post("/api/v1/admin/users/x/rewards", headers=H, json={"black": True, "premium_days": 30})
    assert r.status_code == 200 and r.json()["tick"] == "black" and r.json()["premium"] is True
    assert any("set tick_black = %s" in c[0] for c in db.calls)
    assert any("insert into public.admin_actions" in c[0] for c in db.calls)


def test_tick_step_up_rings_and_gold_gives_premium(db):
    db.respond("update public.profiles p set tick = public.vz_tick", {"tick": "gold", "old": "blue"})
    db.respond("set premium_until = greatest", {"premium_until": LATER})
    assert R.refresh_tick(db, "vahanza", "u1") == "gold"
    assert any("insert into public.notifications" in c[0] for c in db.calls)
    assert any("insert into public.premium_passes" in c[0] and c[1][3] == "gold" for c in db.calls)
