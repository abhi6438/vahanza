"""Rewards: अंक (points), ticks and Premium.

* Points are earned for useful actions; every change is one row in public.reward_ledger, so a reward is given
  once per thing (unique user + kind + ref). They stay inside the app — never turned into money. Coupons,
  cashback and cash will be new ledger kinds later.
* Tick = trust, never bought: gray (profile complete) · blue (ID checked) · gold (blue + proven work) ·
  black (chosen by Vahanza). The rule lives in SQL: public.vz_tick().
* Premium: 30 / 90 days, bought with points or paid. Gold / black tick: 30 days free every month.

Every function here is called through notify.safe() from the routes, so a failure never undoes the user's action.
"""
from __future__ import annotations

import logging
from datetime import datetime, timezone
from typing import Optional

from . import notify

log = logging.getLogger("vz.rewards")

# What each action earns. "cap" = at most this many rewards of the kind in 30 days.
EARN: dict[str, dict] = {
    "profile_done":      {"points": 50,  "roles": ("driver", "owner"), "once": True},
    "verified":          {"points": 100, "roles": ("driver", "owner"), "once": True},
    "history_add":       {"points": 10,  "roles": ("driver",), "cap": 5},
    "history_confirmed": {"points": 100, "roles": ("driver",)},
    "history_answered":  {"points": 30,  "roles": ("owner",), "cap": 20},
    "hire_confirmed":    {"points": 100, "roles": ("driver", "owner")},
    "post_live":         {"points": 20,  "roles": ("owner",), "cap": 5},
    "rating_given":      {"points": 10,  "roles": ("driver", "owner"), "cap": 10},
    "referral":          {"points": 50,  "roles": ("driver", "owner"), "cap": 10},
    "weekly_active":     {"points": 20,  "roles": ("driver", "owner")},
}
BIG = {"verified", "history_confirmed", "hire_confirmed", "referral"}     # worth a bell / push

# Premium plans: days, price in points and in rupees (paid).
PLANS: dict[str, dict[str, dict]] = {
    "driver": {"m1": {"days": 30, "points": 500, "rupees": 49}, "m3": {"days": 90, "points": 1300, "rupees": 129}},
    "owner":  {"m1": {"days": 30, "points": 800, "rupees": 99}, "m3": {"days": 90, "points": 2000, "rupees": 249}},
}
GOLD_DAYS = 30
TICK_RANK = {None: 0, "gray": 1, "blue": 2, "gold": 3, "black": 4}

# Premium extras (limits that grow with Premium)
MAX_HISTORY = {False: 15, True: 30}
MAX_LIVE_POSTS = {False: 10, True: 25}


def is_premium(until) -> bool:
    return bool(until) and until > datetime.now(timezone.utc)


def premium_of(db, user_id: str) -> bool:
    row = db.execute("select premium_until from public.profiles where id = %s", (user_id,)).fetchone()
    return bool(row) and is_premium(row.get("premium_until"))


# ---------------------------------------------------------------- points
def award(db, tenant: str, user_id: str, kind: str, ref: str = "", *, role: Optional[str] = None) -> int:
    """Give the points for `kind` once per (user, kind, ref). Returns the points given (0 = already / capped)."""
    rule = EARN.get(kind)
    if not rule or not user_id:
        return 0
    if role and role not in rule["roles"]:
        return 0
    if rule.get("cap"):
        n = db.execute(
            "select count(*) as n from public.reward_ledger where user_id = %s and kind = %s and created_at > now() - interval '30 days'",
            (user_id, kind),
        ).fetchone()
        if n and n["n"] >= rule["cap"]:
            return 0
    row = db.execute(
        """insert into public.reward_ledger (tenant_id, user_id, kind, points, ref) values (%s, %s, %s, %s, %s)
           on conflict (user_id, kind, ref) do nothing returning points""",
        (tenant, user_id, kind, rule["points"], "" if rule.get("once") else str(ref)),
    ).fetchone()
    if not row:
        return 0
    db.execute("update public.profiles set points = points + %s where id = %s", (row["points"], user_id))
    if kind in BIG:
        notify.safe(db, notify.to_user, tenant, user_id, "reward", {"what": "points", "kind": kind, "points": row["points"]})
    return row["points"]


def spend(db, tenant: str, user_id: str, points: int, kind: str, ref: str, note: str | None = None) -> bool:
    """Take points (e.g. Premium). False when the balance is too small."""
    row = db.execute(
        "update public.profiles set points = points - %s where id = %s and points >= %s returning points",
        (points, user_id, points),
    ).fetchone()
    if not row:
        return False
    db.execute(
        "insert into public.reward_ledger (tenant_id, user_id, kind, points, ref, note) values (%s, %s, %s, %s, %s, %s)",
        (tenant, user_id, kind, -points, ref, note),
    )
    return True


def admin_adjust(db, tenant: str, user_id: str, points: int, admin_id: str, note: str | None) -> None:
    db.execute(
        "insert into public.reward_ledger (tenant_id, user_id, kind, points, ref, note) values (%s, %s, 'admin', %s, %s, %s)",
        (tenant, user_id, points, f"{admin_id}:{datetime.now(timezone.utc).timestamp():.0f}", note),
    )
    db.execute("update public.profiles set points = greatest(0, points + %s) where id = %s", (points, user_id))


# ---------------------------------------------------------------- tick
def refresh_tick(db, tenant: str, user_id: str) -> Optional[str]:
    """Recompute one person's tick. A step up rings the bell; gold / black also switch on the monthly Premium."""
    if not user_id:
        return None
    row = db.execute(
        """with o as (select tick as old from public.profiles where id = %s)
           update public.profiles p set tick = public.vz_tick(p.id) from o where p.id = %s
           returning p.tick, o.old""",
        (user_id, user_id),
    ).fetchone()
    if not row:
        return None
    new, old = row.get("tick"), row.get("old")
    if TICK_RANK.get(new, 0) > TICK_RANK.get(old, 0):
        notify.safe(db, notify.to_user, tenant, user_id, "reward", {"what": "tick", "tick": new})
        if new in ("gold", "black"):
            grant_gold(db, tenant, user_id)
    return new


def check_profile(db, tenant: str, user_id: str, role: str) -> None:
    """After a profile save: profile complete → points (and the person who invited them gets theirs) + tick."""
    if role == "driver":
        ok = db.execute(
            "select 1 as ok from public.driver_details where profile_id = %s and cardinality(vehicles) > 0 and available_from is not null",
            (user_id,),
        ).fetchone()
    else:
        ok = db.execute("select 1 as ok from public.fleet_groups where owner_id = %s limit 1", (user_id,)).fetchone()
    if ok:
        if award(db, tenant, user_id, "profile_done", role=role):
            ref = db.execute("select referred_by from public.profiles where id = %s", (user_id,)).fetchone()
            if ref and ref.get("referred_by"):
                award(db, tenant, str(ref["referred_by"]), "referral", user_id)
    refresh_tick(db, tenant, user_id)


# ---------------------------------------------------------------- premium
def grant_premium(db, tenant: str, user_id: str, days: int, source: str, plan: str,
                  points: int | None = None, amount_paise: int | None = None, order_id: str | None = None) -> datetime:
    row = db.execute(
        """update public.profiles set premium_until = greatest(coalesce(premium_until, now()), now()) + make_interval(days => %s)
           where id = %s returning premium_until""",
        (days, user_id),
    ).fetchone()
    db.execute(
        """insert into public.premium_passes (tenant_id, user_id, plan, source, days, points, amount_paise, order_id, ends_at)
           values (%s, %s, %s, %s, %s, %s, %s, %s, %s)""",
        (tenant, user_id, plan, source, days, points, amount_paise, order_id, row["premium_until"]),
    )
    notify.safe(db, notify.to_user, tenant, user_id, "reward", {"what": "premium", "days": days, "source": source})
    return row["premium_until"]


def grant_gold(db, tenant: str, user_id: str) -> bool:
    """Gold / black tick: 30 days Premium, once per calendar month."""
    done = db.execute(
        "select 1 as x from public.premium_passes where user_id = %s and source = 'gold' and created_at >= date_trunc('month', now())",
        (user_id,),
    ).fetchone()
    if done:
        return False
    grant_premium(db, tenant, user_id, GOLD_DAYS, "gold", "gold")
    return True


# ---------------------------------------------------------------- daily job
def daily(db, today) -> dict:
    """Ticks for everyone (ratings / fast-reply change quietly), the monthly gold Premium, Monday "active this week"."""
    changed = db.execute(
        """update public.profiles set tick = public.vz_tick(id)
           where role in ('driver', 'owner') and tick is distinct from public.vz_tick(id) returning id""",
    ).fetchall() or []
    gold = db.execute(
        """select id, tenant_id from public.profiles p where tick in ('gold', 'black') and not blocked
             and not exists (select 1 from public.premium_passes x where x.user_id = p.id and x.source = 'gold'
                              and x.created_at >= date_trunc('month', now()))""",
    ).fetchall() or []
    for r in gold:
        notify.safe(db, grant_gold, r["tenant_id"], str(r["id"]))
    weekly = 0
    if today.weekday() == 0:
        week = f"{today.isocalendar()[0]}-W{today.isocalendar()[1]:02d}"
        rows = db.execute(
            """with ins as (
                 insert into public.reward_ledger (tenant_id, user_id, kind, points, ref)
                 select tenant_id, id, 'weekly_active', %s, %s from public.profiles
                  where role in ('driver', 'owner') and setup_done and not blocked and last_seen_at > now() - interval '7 days'
                 on conflict (user_id, kind, ref) do nothing returning user_id, points)
               update public.profiles p set points = p.points + ins.points from ins where p.id = ins.user_id returning p.id""",
            (EARN["weekly_active"]["points"], week),
        ).fetchall() or []
        weekly = len(rows)
    return {"ticks": len(changed), "gold": len(gold), "weekly": weekly}


# ---------------------------------------------------------------- the user's own page
def ladder(db, user_id: str, role: str) -> list[dict]:
    """The four ticks with what each needs and what is already done (the Rewards page shows the next step)."""
    p = db.execute(
        """select p.verified, p.setup_done, p.rating_avg, p.jobs_done, p.fast_reply, p.tick, p.tick_black,
                  (select count(*) from public.work_history wh where wh.driver_id = p.id and wh.status in ('confirmed', 'admin_ok')) as confirmed,
                  exists (select 1 from public.driver_details d where d.profile_id = p.id and cardinality(d.vehicles) > 0 and d.available_from is not null) as drv_ok,
                  exists (select 1 from public.fleet_groups f where f.owner_id = p.id) as own_ok
           from public.profiles p where p.id = %s""",
        (user_id,),
    ).fetchone() or {}
    rating = float(p.get("rating_avg") or 0)
    complete = bool(p.get("setup_done")) and bool(p.get("drv_ok") if role == "driver" else p.get("own_ok"))
    verified = bool(p.get("verified"))
    if role == "driver":
        gold = [{"key": "verified", "done": verified},
                {"key": "history2", "done": (p.get("confirmed") or 0) >= 2, "have": p.get("confirmed") or 0, "need": 2},
                {"key": "rating4", "done": rating >= 4, "have": round(rating, 1)}]
    else:
        gold = [{"key": "verified", "done": verified},
                {"key": "hires3", "done": (p.get("jobs_done") or 0) >= 3, "have": p.get("jobs_done") or 0, "need": 3},
                {"key": "fastOrRating", "done": bool(p.get("fast_reply")) or rating >= 4}]
    return [
        {"tick": "gray", "steps": [{"key": "profile", "done": complete}]},
        {"tick": "blue", "steps": [{"key": "verify", "done": verified}]},
        {"tick": "gold", "steps": gold},
        {"tick": "black", "steps": [{"key": "chosen", "done": bool(p.get("tick_black"))}]},
    ]


def earn_list(db, user_id: str, role: str) -> list[dict]:
    rows = db.execute(
        """select kind, count(*) filter (where created_at > now() - interval '30 days') as month, count(*) as total
           from public.reward_ledger where user_id = %s group by kind""",
        (user_id,),
    ).fetchall() or []
    got = {r["kind"]: r for r in rows}
    out = []
    for kind, rule in EARN.items():
        if role not in rule["roles"]:
            continue
        g = got.get(kind) or {}
        out.append({"kind": kind, "points": rule["points"], "once": bool(rule.get("once")), "cap": rule.get("cap"),
                    "done": bool(g.get("total")) if rule.get("once") else False, "month": g.get("month") or 0})
    return out
