"""Rewards page, Premium (points or paid), "who saw me" (Premium), admin tools.

GET  /me/rewards                    balance, tick ladder, ways to earn, Premium plans, last ledger rows
POST /me/premium/points {plan}      buy Premium with points
POST /me/premium/order  {plan}      paid: create a Razorpay order (only when keys are set)
POST /me/premium/paid               paid: check the checkout signature → Premium on
POST /hooks/razorpay                Razorpay webhook (payment.captured) — Premium on even if the app closed
GET  /me/profile-viewers            driver: owners who opened my profile (names = Premium, count = everyone)
GET  /posts/{id}/viewers            owner: drivers who opened my post (names = Premium, count = everyone)
POST /admin/users/{id}/rewards      admin: black tick on/off, give Premium days, add / take points
"""
import hashlib
import hmac
import json
import logging
import secrets
from typing import Literal, Optional

import httpx
from fastapi import APIRouter, Depends, Header, HTTPException, Request
from pydantic import BaseModel, Field

from .. import notify, rewards as R
from ..auth import AuthUser, current_user
from ..config import get_settings
from ..deps import get_db, tenant_id
from .admin import _audit, admin_ctx

router = APIRouter(tags=["rewards"])
log = logging.getLogger("vz.rewards")


def _me(db, user: AuthUser, tenant: str) -> dict:
    me = db.execute(
        "select id, tenant_id, role, blocked, name, phone, points, tick, premium_until, is_test from public.profiles where id = %s",
        (user.id,),
    ).fetchone()
    if not me or me["tenant_id"] != tenant:
        raise HTTPException(404, "Profile not found")
    if me["blocked"]:
        raise HTTPException(403, "Account blocked")
    if me["role"] not in ("driver", "owner"):
        raise HTTPException(403, {"code": "role"})
    return me


def _pay_on() -> bool:
    s = get_settings()
    return bool(s.razorpay_key_id and s.razorpay_key_secret)


def _plans(role: str) -> list[dict]:
    return [{"id": k, **v} for k, v in R.PLANS[role].items()]


def _iso(v):
    return v.isoformat() if v is not None else None


@router.get("/me/rewards")
def my_rewards(user: AuthUser = Depends(current_user), db=Depends(get_db), tenant: str = Depends(tenant_id)):
    me = _me(db, user, tenant)
    role = me["role"]
    ledger = db.execute(
        "select kind, points, ref, note, created_at from public.reward_ledger where user_id = %s order by created_at desc, id desc limit 30",
        (user.id,),
    ).fetchall() or []
    gold_month = db.execute(
        "select 1 as x from public.premium_passes where user_id = %s and source = 'gold' and created_at >= date_trunc('month', now())",
        (user.id,),
    ).fetchone()
    return {
        "role": role,
        "points": me["points"] or 0,
        "tick": me["tick"],
        "premium": R.is_premium(me["premium_until"]),
        "premium_until": _iso(me["premium_until"]),
        "gold_free_used": bool(gold_month),
        "ladder": R.ladder(db, user.id, role),
        "earn": R.earn_list(db, user.id, role),
        "plans": _plans(role),
        "pay_enabled": _pay_on(),
        "ledger": [{"kind": r["kind"], "points": r["points"], "note": r["note"], "at": _iso(r["created_at"])} for r in ledger],
    }


class PlanIn(BaseModel):
    plan: Literal["m1", "m3"]


@router.post("/me/premium/points")
def premium_with_points(body: PlanIn, user: AuthUser = Depends(current_user), db=Depends(get_db), tenant: str = Depends(tenant_id)):
    me = _me(db, user, tenant)
    plan = R.PLANS[me["role"]][body.plan]
    ref = secrets.token_hex(6)
    if not R.spend(db, tenant, user.id, plan["points"], "premium", ref, f"{body.plan}:{plan['days']}d"):
        raise HTTPException(409, {"code": "not_enough", "need": plan["points"], "have": me["points"] or 0})
    until = R.grant_premium(db, tenant, user.id, plan["days"], "points", body.plan, points=plan["points"])
    return {"premium": True, "premium_until": _iso(until)}


# ---------------------------------------------------------------- paid (Razorpay)
@router.post("/me/premium/order")
def premium_order(body: PlanIn, user: AuthUser = Depends(current_user), db=Depends(get_db), tenant: str = Depends(tenant_id)):
    me = _me(db, user, tenant)
    if not _pay_on():
        raise HTTPException(503, {"code": "pay_off"})
    s = get_settings()
    plan = R.PLANS[me["role"]][body.plan]
    amount = plan["rupees"] * 100
    try:
        r = httpx.post("https://api.razorpay.com/v1/orders", auth=(s.razorpay_key_id, s.razorpay_key_secret), timeout=15,
                       json={"amount": amount, "currency": "INR", "receipt": f"vz-{secrets.token_hex(6)}",
                             "notes": {"user": str(user.id), "plan": body.plan, "tenant": tenant}})
        r.raise_for_status()
        order = r.json()
    except Exception as e:  # noqa: BLE001
        log.warning("razorpay order failed: %s", e)
        raise HTTPException(502, {"code": "pay_failed"})
    db.execute(
        "insert into public.payment_orders (order_id, tenant_id, user_id, plan, amount_paise) values (%s, %s, %s, %s, %s)",
        (order["id"], tenant, user.id, body.plan, amount),
    )
    # the person's own number pre-fills the checkout (never anyone else's)
    return {"order_id": order["id"], "key_id": s.razorpay_key_id, "amount": amount, "currency": "INR",
            "contact": f"+{me['phone']}" if me.get("phone") else None, "name": me.get("name")}


def _settle(db, order_id: str, payment_id: str) -> Optional[str]:
    """Mark the order paid once and switch Premium on. Returns premium_until (None if already done / unknown)."""
    row = db.execute(
        "update public.payment_orders set status = 'paid', payment_id = %s, paid_at = now() where order_id = %s and status = 'created' "
        "returning tenant_id, user_id, plan, amount_paise",
        (payment_id, order_id),
    ).fetchone()
    if not row:
        return None
    role = db.execute("select role from public.profiles where id = %s", (row["user_id"],)).fetchone()
    plan = R.PLANS.get((role or {}).get("role") or "driver", R.PLANS["driver"]).get(row["plan"]) or {"days": 30}
    until = R.grant_premium(db, row["tenant_id"], str(row["user_id"]), plan["days"], "paid", row["plan"],
                            amount_paise=row["amount_paise"], order_id=order_id)
    return _iso(until)


class PaidIn(BaseModel):
    order_id: str = Field(max_length=60)
    payment_id: str = Field(max_length=60)
    signature: str = Field(max_length=200)


@router.post("/me/premium/paid")
def premium_paid(body: PaidIn, user: AuthUser = Depends(current_user), db=Depends(get_db), tenant: str = Depends(tenant_id)):
    _me(db, user, tenant)
    s = get_settings()
    if not _pay_on():
        raise HTTPException(503, {"code": "pay_off"})
    want = hmac.new(s.razorpay_key_secret.encode(), f"{body.order_id}|{body.payment_id}".encode(), hashlib.sha256).hexdigest()
    if not hmac.compare_digest(want, body.signature):
        raise HTTPException(400, {"code": "bad_signature"})
    mine = db.execute("select status from public.payment_orders where order_id = %s and user_id = %s", (body.order_id, user.id)).fetchone()
    if not mine:
        raise HTTPException(404, "Order not found")
    until = _settle(db, body.order_id, body.payment_id)
    if until is None:
        until = _iso(db.execute("select premium_until from public.profiles where id = %s", (user.id,)).fetchone()["premium_until"])
    return {"premium": True, "premium_until": until}


@router.post("/hooks/razorpay", status_code=200)
async def razorpay_hook(request: Request, x_razorpay_signature: Optional[str] = Header(default=None), db=Depends(get_db)):
    secret = get_settings().razorpay_webhook_secret
    raw = await request.body()
    if not secret or not x_razorpay_signature:
        raise HTTPException(401, "No signature")
    want = hmac.new(secret.encode(), raw, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(want, x_razorpay_signature):
        raise HTTPException(401, "Bad signature")
    ev = json.loads(raw or b"{}")
    if ev.get("event") in ("payment.captured", "order.paid"):
        pay = ((ev.get("payload") or {}).get("payment") or {}).get("entity") or {}
        if pay.get("order_id") and pay.get("id"):
            _settle(db, pay["order_id"], pay["id"])
    return {"ok": True}


# ---------------------------------------------------------------- who saw me (names = Premium)
@router.get("/me/profile-viewers")
def profile_viewers(user: AuthUser = Depends(current_user), db=Depends(get_db), tenant: str = Depends(tenant_id)):
    me = _me(db, user, tenant)
    if me["role"] != "driver":
        raise HTTPException(403, {"code": "role"})
    n = db.execute(
        """select count(distinct viewer_id) filter (where day > current_date - 7) as week,
                  count(distinct viewer_id) filter (where day > current_date - 30) as month
           from public.profile_views where driver_id = %s""",
        (user.id,),
    ).fetchone() or {}
    premium = R.is_premium(me["premium_until"])
    items = []
    if premium:
        rows = db.execute(
            """select o.id, o.name, o.business_name, o.district, o.state, o.photo_url, o.tick, max(v.day) as day
               from public.profile_views v join public.profiles o on o.id = v.viewer_id
               where v.driver_id = %s and v.day > current_date - 30 and not o.blocked
               group by o.id order by max(v.day) desc limit 50""",
            (user.id,),
        ).fetchall() or []
        items = [{"id": str(r["id"]), "name": (r["name"] or "").split(" ")[0] or None, "firm": r["business_name"],
                  "district": r["district"], "state": r["state"], "photo_url": r["photo_url"], "tick": r["tick"],
                  "day": _iso(r["day"])} for r in rows]
    return {"week": n.get("week") or 0, "month": n.get("month") or 0, "premium": premium, "items": items}


@router.get("/posts/{post_id}/viewers")
def post_viewers(post_id: str, user: AuthUser = Depends(current_user), db=Depends(get_db), tenant: str = Depends(tenant_id)):
    me = _me(db, user, tenant)
    if me["role"] != "owner":
        raise HTTPException(403, {"code": "role"})
    own = db.execute("select 1 as x from public.posts where id = %s and owner_id = %s", (post_id, user.id)).fetchone()
    if not own:
        raise HTTPException(404, "Not found")
    n = db.execute("select count(distinct viewer_id) as n from public.post_views where post_id = %s", (post_id,)).fetchone() or {}
    premium = R.is_premium(me["premium_until"])
    items = []
    if premium:
        rows = db.execute(
            """select d.id, d.name, d.district, d.state, d.photo_url, d.tick, max(v.day) as day,
                      dd.vehicles, dd.experience_years
               from public.post_views v join public.profiles d on d.id = v.viewer_id
               left join public.driver_details dd on dd.profile_id = d.id
               where v.post_id = %s and not d.blocked group by d.id, dd.vehicles, dd.experience_years
               order by max(v.day) desc limit 100""",
            (post_id,),
        ).fetchall() or []
        items = [{"id": str(r["id"]), "name": r["name"], "district": r["district"], "state": r["state"],
                  "photo_url": r["photo_url"], "tick": r["tick"], "day": _iso(r["day"]),
                  "vehicles": r["vehicles"] or [], "experience_years": r["experience_years"]} for r in rows]
    return {"count": n.get("n") or 0, "premium": premium, "items": items}


# ---------------------------------------------------------------- admin
class AdminRewardIn(BaseModel):
    black: Optional[bool] = None
    premium_days: Optional[int] = Field(None, ge=1, le=365)
    points: Optional[int] = Field(None, ge=-10000, le=10000)
    note: Optional[str] = Field(None, max_length=200)


@router.post("/admin/users/{profile_id}/rewards")
def admin_rewards(profile_id: str, body: AdminRewardIn, ctx: dict = Depends(admin_ctx), db=Depends(get_db)):
    who = db.execute(
        "select id, role from public.profiles where id = %s and tenant_id = %s and role in ('driver', 'owner')",
        (profile_id, ctx["tenant"]),
    ).fetchone()
    if not who:
        raise HTTPException(404, "Not found")
    if body.black is not None:
        db.execute("update public.profiles set tick_black = %s where id = %s", (body.black, profile_id))
        _audit(db, ctx, "tick_black_on" if body.black else "tick_black_off", "reward", profile_id, body.note)
        R.refresh_tick(db, ctx["tenant"], profile_id)
    if body.premium_days:
        R.grant_premium(db, ctx["tenant"], profile_id, body.premium_days, "admin", "admin")
        _audit(db, ctx, "premium_give", "reward", profile_id, f"{body.premium_days}d" + (f": {body.note}" if body.note else ""))
    if body.points:
        R.admin_adjust(db, ctx["tenant"], profile_id, body.points, ctx["id"], body.note)
        _audit(db, ctx, "points_adjust", "reward", profile_id, f"{body.points:+d}" + (f": {body.note}" if body.note else ""))
    row = db.execute("select tick, tick_black, points, premium_until from public.profiles where id = %s", (profile_id,)).fetchone()
    return {"tick": row["tick"], "tick_black": row["tick_black"], "points": row["points"],
            "premium": R.is_premium(row["premium_until"]), "premium_until": _iso(row["premium_until"])}
